# DjangoMongodbCRUD
DjangoMongodbCRUD Django Mongo DB CRUD Using djongo
